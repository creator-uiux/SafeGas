package com.example.myapplication

class LoginPresenter(private val view: LoginContract.View) : LoginContract.Presenter {

    override fun onLoginClicked(email: String, password: String) {
        if (email.isEmpty() || password.isEmpty()) {
            view.showValidationError("Email and password are required.")
            return
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            view.showValidationError("Invalid email format.")
            return
        }

        // Simulate login success
        if (email == "test@example.com" && password == "password123") {
            view.showLoginSuccess()
        } else {
            view.showLoginError("Invalid email or password.")
        }
    }
}