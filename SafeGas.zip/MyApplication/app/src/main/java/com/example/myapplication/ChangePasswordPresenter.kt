package com.example.myapplication

class ChangePasswordPresenter {
}