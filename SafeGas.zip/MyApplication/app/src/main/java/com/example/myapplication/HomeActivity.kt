package com.example.myapplication

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class HomeActivity : Activity(), HomeContract.View {

    private lateinit var presenter: HomeContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home_activity) // Ensure your XML file is named activity_home.xml

        presenter = HomePresenter(this, HomeModelImpl())

        findViewById<Button>(R.id.btnCheckGasLevels).setOnClickListener {
            presenter.onCheckGasLevelsClicked()
        }

        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            presenter.onLogoutClicked()
        }
    }

    override fun showGasLevel(level: Int) {
        Toast.makeText(this, "Gas Level: $level%", Toast.LENGTH_SHORT).show()
    }

    override fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }



    override fun navigateToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    override fun showLoading() {
        Toast.makeText(this, "Loading...", Toast.LENGTH_SHORT).show()
    }

    override fun hideLoading() {
        // You can dismiss a loading spinner here if you add one
    }
}
